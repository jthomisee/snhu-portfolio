#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <iostream>
#include <vector>
#include <cmath>
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"



// Global variables for camera control
glm::vec3 cameraPos = glm::vec3(-2.4f, 1.20f, 0.5f);
glm::vec3 cameraFront = glm::vec3(0.28f, -0.29f, -0.90f);
glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);
float cameraSpeed = 0.5f;
bool usePerspective = true;

// Global variables for mouse control
float yaw = glm::degrees(atan2(cameraFront.z, cameraFront.x));
float pitch = glm::degrees(asin(cameraFront.y));
float lastX = 200.0f;
float lastY = 150.0f;
bool firstMouse = true;
bool mouseCaptured = false;

// Light info
glm::vec3 lightPos(-3.4f, 20.0f, 10.0f);
glm::vec3 lightColor(1.0f, 0.7f, 0.4f);  // Warm White light

glm::vec3 computerLightPos(1.5f, 0.25f, -5.0f); // Green light for computer light effects
glm::vec3 computerLightColor(0.3f, 1.0f, 0.0f);

float materialShininess = 32.0f;
float ambientStrength = 0.8f;
float diffuseStrength = 0.5f;
float specularStrength = 0.5f;
float computerDiffuseStrength = 0.8f;


// Vertex shader
const char* vertexShaderSource = R"(
#version 330 core
layout (location = 0) in vec3 aPos;
layout (location = 1) in vec3 aColor;
layout (location = 2) in vec2 aTexCoord;
out vec2 TexCoord;
out vec3 vertexColor;
out vec3 FragPos;
out vec3 LightPos;
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;
uniform vec3 computerLightPos;


void main()
{

    vec4 objectPos = projection * view * model * vec4(aPos, 1.0);
    gl_Position = objectPos;
    vertexColor = aColor;
    TexCoord = aTexCoord;
    FragPos = vec3(model * vec4(aPos, 1.0));
    LightPos = computerLightPos;
}
)";

// Fragment shader
const char* fragmentShaderSource = R"(
#version 330 core
in vec2 TexCoord;
in vec3 vertexColor;
in vec3 FragPos;
in vec3 LightPos;
out vec4 FragColor;
uniform sampler2D textureSampler;
uniform int useBlackColor;
uniform int useGreenColor;
uniform vec3 lightColor;
uniform vec3 lightPos;
uniform vec3 computerLightPos;
uniform vec3 computerLightColor;
uniform vec3 viewPos;
uniform vec3 objectColor;
uniform float ambientStrength;
uniform float diffuseStrength;
uniform float computerDiffuseStrength;
uniform float specularStrength;
uniform float materialShininess;

void main()
{

    vec3 norm = normalize(vec3(0.0, 1.0, 0.0));

    vec3 computerLightDir = normalize(computerLightPos - FragPos);
    float computerDiff = max(dot(norm, computerLightDir), 0.0);
    vec3 computerDiffuse = computerDiffuseStrength * computerDiff * computerLightColor;

    vec3 lightDir = normalize(lightPos - FragPos);

    float diff = max(dot(norm, lightDir), 0.0);

    vec3 diffuse = diffuseStrength * diff * lightColor;

    vec3 viewDir = normalize(viewPos - FragPos); 
    vec3 reflectDir = reflect(-lightDir, norm); 
    float spec = pow(max(dot(viewDir, reflectDir), 0.0), materialShininess);
    vec3 specular = specularStrength * spec * lightColor;

    vec3 ambient = ambientStrength * lightColor;

    vec3 lighting = (ambient + diffuse + specular) + computerDiffuse;

    if (useBlackColor == 1) {
        FragColor = vec4(0.0, 0.0, 0.0, 1.0);
    } else if (useGreenColor == 1) {
        FragColor = vec4(0.0, 1.5, 0.0, 1.0);
    } else {
        vec4 textureColor = texture(textureSampler, TexCoord);
        FragColor = vec4(lighting * textureColor.rgb, textureColor.a);
    }
}
)";

void resetView() {

    cameraPos = glm::vec3(-2.4f, 1.20f, 0.5f);
    cameraFront = glm::vec3(0.28f, -0.29f, -0.90f);
    cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);
    cameraSpeed = 0.5f;
    usePerspective = true;

    yaw = glm::degrees(atan2(cameraFront.z, cameraFront.x));
    pitch = glm::degrees(asin(cameraFront.y));
    lastX = 200.0f;
    lastY = 150.0f;
    firstMouse = true;
}

// Callback function for handling key inputs
void key_callback(GLFWwindow* window, int key, int scancode, int action, int mods) {
    if (action == GLFW_PRESS || action == GLFW_REPEAT) {
        if (key == GLFW_KEY_W) {
            cameraPos += cameraSpeed * cameraFront;
        }
        if (key == GLFW_KEY_S) {
            cameraPos -= cameraSpeed * cameraFront;
        }
        if (key == GLFW_KEY_A) {
            cameraPos -= glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
        }
        if (key == GLFW_KEY_D) {
            cameraPos += glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
        }
        if (key == GLFW_KEY_Q) {
            cameraPos += cameraSpeed * cameraUp;
        }
        if (key == GLFW_KEY_E) {
            cameraPos -= cameraSpeed * cameraUp;
        }
        if (key == GLFW_KEY_P) {
            usePerspective = !usePerspective;  // Toggle projection mode
        }
        if (key == GLFW_KEY_R) {
            resetView(); // Reset to initial view
        }
        // Debug code for moving the light around
        /*
        if (key == GLFW_KEY_UP) {
            lightPos.y += 1;
        }
        if (key == GLFW_KEY_DOWN) {
            lightPos.y -= 1;
        }
        if (key == GLFW_KEY_RIGHT) {
            lightPos.x += 1;
        }
        if (key == GLFW_KEY_LEFT) {
            lightPos.x -= 1;
        }
        if (key == GLFW_KEY_LEFT_BRACKET) {
            lightPos.z -= 1;
        }
        if (key == GLFW_KEY_RIGHT_BRACKET) {
            lightPos.z += 1;
        }
        */

        if (key == GLFW_KEY_ESCAPE) {
            mouseCaptured = false; // Release mouse capture
            glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_NORMAL);
            firstMouse = true; // Reset the firstMouse flag
        }


        // Debug Code
        //std::cout << "Camera Position: (" << cameraPos.x << ", " << cameraPos.y << ", " << cameraPos.z << ")" << std::endl;
        //std::cout << "Camera Front: (" << cameraFront.x << ", " << cameraFront.y << ", " << cameraFront.z << ")" << std::endl;
        //std::cout << "Lighting Position: (" << lightPos.x << ", " << lightPos.y << ", " << lightPos.z << ")" << std::endl;

    }
}

// Callback function for handling mouse movement
void mouse_callback(GLFWwindow* window, double xpos, double ypos) {

    if (mouseCaptured) {
        if (firstMouse) {
            lastX = xpos;
            lastY = ypos;
            firstMouse = false;
        }
        else {
            float xoffset = xpos - lastX;
            float yoffset = lastY - ypos;  // Reversed since y-coordinates go from bottom to top
            lastX = xpos;
            lastY = ypos;

            float sensitivity = 0.1f;
            xoffset *= sensitivity;
            yoffset *= sensitivity;

            yaw += xoffset;
            pitch += yoffset;


            // Make sure that when pitch is out of bounds, the screen doesn't get flipped
            if (pitch > 89.0f)
                pitch = 89.0f;
            if (pitch < -89.0f)
                pitch = -89.0f;

            glm::vec3 front;
            front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
            front.y = sin(glm::radians(pitch));
            front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
            cameraFront = glm::normalize(front);
        }
    }
}

void mouse_button_callback(GLFWwindow* window, int button, int action, int mods) {
    if (button == GLFW_MOUSE_BUTTON_LEFT && action == GLFW_PRESS) {
        mouseCaptured = true; // Capture mouse
        glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);
        firstMouse = true; // Reset the firstMouse flag
    }
}


// Callback function for handling mouse scroll
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset) {
    cameraSpeed += yoffset * 0.01f;
}

void framebuffer_size_callback(GLFWwindow* window, int width, int height) {
    glViewport(0, 0, width, height);
}


#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
void generateCylinder(float radius, float height, int segments, std::vector<float>& vertices) {
    float angleIncrement = 2.0f * M_PI / segments;

    // Top circle
    for (int i = 0; i <= segments; ++i) {
        float angle = angleIncrement * i;
        vertices.push_back(radius * cos(angle));
        vertices.push_back(height / 2.0f);
        vertices.push_back(radius * sin(angle));
        vertices.push_back(0.0f); // R
        vertices.push_back(0.0f); // G
        vertices.push_back(0.0f); // B
    }

    // Bottom circle
    for (int i = 0; i <= segments; ++i) {
        float angle = angleIncrement * i;
        vertices.push_back(radius * cos(angle));
        vertices.push_back(-height / 2.0f);
        vertices.push_back(radius * sin(angle));
        vertices.push_back(0.0f); // R
        vertices.push_back(0.0f); // G
        vertices.push_back(0.0f); // B
    }

    // Lateral surface
    for (int i = 0; i <= segments; ++i) {
        float angle = angleIncrement * i;
        // Top vertex
        vertices.push_back(radius * cos(angle));
        vertices.push_back(height / 2.0f);
        vertices.push_back(radius * sin(angle));
        vertices.push_back(0.0f); // R
        vertices.push_back(0.0f); // G
        vertices.push_back(0.0f); // B

        // Bottom vertex
        vertices.push_back(radius * cos(angle));
        vertices.push_back(-height / 2.0f);
        vertices.push_back(radius * sin(angle));
        vertices.push_back(0.0f); // R
        vertices.push_back(0.0f); // G
        vertices.push_back(0.0f); // B
    }
}

struct Vertex {
    float x, y, z;
    float nx, ny, nz; // normals
};

std::vector<Vertex> generateTorus(float outerRadius, float innerRadius, int numMajor, int numMinor) {
    std::vector<Vertex> vertices;
    float majorStep = 2.0f * M_PI / numMajor;
    float minorStep = 2.0f * M_PI / numMinor;

    for (int i = 0; i < numMajor; ++i) {
        float a0 = i * majorStep;
        float a1 = a0 + majorStep;
        float xMajor0 = cos(a0);
        float yMajor0 = sin(a0);
        float xMajor1 = cos(a1);
        float yMajor1 = sin(a1);

        for (int j = 0; j <= numMinor; ++j) {
            float b = j * minorStep;
            float cosb = cos(b);
            float sinb = sin(b);

            Vertex vertex;

            vertex.x = xMajor0 * (outerRadius + innerRadius * cosb);
            vertex.y = yMajor0 * (outerRadius + innerRadius * cosb);
            vertex.z = innerRadius * sinb;
            vertex.nx = xMajor0 * cosb;
            vertex.ny = yMajor0 * cosb;
            vertex.nz = sinb;

            vertices.push_back(vertex);

            vertex.x = xMajor1 * (outerRadius + innerRadius * cosb);
            vertex.y = yMajor1 * (outerRadius + innerRadius * cosb);
            vertex.z = innerRadius * sinb;
            vertex.nx = xMajor1 * cosb;
            vertex.ny = yMajor1 * cosb;
            vertex.nz = sinb;

            vertices.push_back(vertex);
        }
    }
    return vertices;
}


void SetModelTransformations(glm::mat4& model, glm::vec3 translation, glm::vec3 rotation, glm::vec3 scale, GLint modelMatrixLoc) {
    model = glm::mat4(1.0f);
    model = glm::translate(model, translation);
    model = glm::rotate(model, glm::radians(rotation.x), glm::vec3(1.0f, 0.0f, 0.0f));
    model = glm::rotate(model, glm::radians(rotation.y), glm::vec3(0.0f, 1.0f, 0.0f));
    model = glm::rotate(model, glm::radians(rotation.z), glm::vec3(0.0f, 0.0f, 1.0f));
    model = glm::scale(model, scale);
    glUniformMatrix4fv(modelMatrixLoc, 1, GL_FALSE, glm::value_ptr(model));
}

void DrawTorusComputerLight(GLuint fanVAO, glm::vec3 position, glm::vec3 rotation, GLint modelMatrixLoc, GLint useGreenColorLoc, int torusVerticesSize) {
    glBindVertexArray(fanVAO);
    glm::mat4 model;
    SetModelTransformations(model, position, rotation, glm::vec3(0.1f), modelMatrixLoc);

    glUniform1i(useGreenColorLoc, 1);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, torusVerticesSize);
    glUniform1i(useGreenColorLoc, 0);
    glBindVertexArray(0);
}

void DrawFan(GLuint cylinderVAO, glm::vec3 position, glm::vec3 rotation, GLuint monitorTexture, GLint modelMatrixLoc, GLint textureSamplerLoc) {
    glBindVertexArray(cylinderVAO);
    glm::mat4 model;
    SetModelTransformations(model, position, rotation, glm::vec3(0.5f, 0.1f, 0.5f), modelMatrixLoc);

    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, monitorTexture);
    glUniform1i(textureSamplerLoc, 1);

    glDrawArrays(GL_TRIANGLE_FAN, 0, 34);
    glDrawArrays(GL_TRIANGLE_FAN, 34, 34);
    glDrawArrays(GL_TRIANGLE_STRIP, 68, 66);
}

void DrawFanWithTorus(
    GLuint fanVAO, GLuint cylinderVAO,
    glm::vec3 position, glm::vec3 fanRotation, glm::vec3 torusRotation,
    GLuint monitorTexture,
    GLint modelMatrixLoc, GLint textureSamplerLoc, GLint useGreenColorLoc,
    int torusVerticesSize
) {
    // Draw the torus
    DrawTorusComputerLight(fanVAO, position, torusRotation, modelMatrixLoc, useGreenColorLoc, torusVerticesSize);

    // Draw the fan
    DrawFan(cylinderVAO, position, fanRotation, monitorTexture, modelMatrixLoc, textureSamplerLoc);
}

void bindTexture(GLint textureUnit, GLuint texture, GLint samplerLoc) {
    glActiveTexture(GL_TEXTURE0 + textureUnit);
    glBindTexture(GL_TEXTURE_2D, texture);
    glUniform1i(samplerLoc, textureUnit);
}

void drawDesk(GLuint modelMatrixLoc, GLuint deskVAO, GLuint deskTexture, GLuint textureSamplerLoc, GLuint deskVBO) {
    // Draw the desk surface
    glBindVertexArray(deskVAO);
    glm::mat4 model = glm::mat4(1.0f);
    model = glm::translate(model, glm::vec3(0.0f, -0.3f, -5.0f));
    model = glm::scale(model, glm::vec3(4.3f, 0.1f, 2.0f));
    glUniformMatrix4fv(modelMatrixLoc, 1, GL_FALSE, glm::value_ptr(model));

    bindTexture(0, deskTexture, textureSamplerLoc);

    glDrawArrays(GL_TRIANGLES, 0, 36);

    // Draw the desk legs
    for (float x : {-2.0f, 2.0f}) {
        for (float z : {-0.8f, 0.8f}) {
            glBindVertexArray(deskVAO);
            model = glm::mat4(1.0f);
            model = glm::translate(model, glm::vec3(x, -0.8f, z - 5.0f));
            model = glm::scale(model, glm::vec3(0.1f, 1.0f, 0.1f));
            glUniformMatrix4fv(modelMatrixLoc, 1, GL_FALSE, glm::value_ptr(model));

            // Set texture coordinates for the desk legs
            glBindBuffer(GL_ARRAY_BUFFER, deskVBO);
            GLfloat* texCoordsLegs = (GLfloat*)glMapBuffer(GL_ARRAY_BUFFER, GL_WRITE_ONLY);
            for (int i = 0; i < 6; ++i) {
                texCoordsLegs[8 * i + 6] = 0.0f;
                texCoordsLegs[8 * i + 7] = 0.0f;
            }
            glUnmapBuffer(GL_ARRAY_BUFFER);
            glBindBuffer(GL_ARRAY_BUFFER, 0);

            glDrawArrays(GL_TRIANGLES, 0, 36);
        }
    }
}

void drawMonitor(
    GLuint cylinderVAO,
    GLuint deskVAO,
    GLuint deskVBO,
    GLuint modelMatrixLoc,
    GLuint useBlackColorLoc,
    GLuint monitorTexture,
    GLuint textureSamplerLoc)
{
    // Drawing the cylinder
    glBindVertexArray(cylinderVAO);
    glUniform1i(useBlackColorLoc, 1);

    glm::mat4 model = glm::mat4(1.0f);
    model = glm::translate(model, glm::vec3(-0.3f, -0.15f, -4.5f));
    model = glm::scale(model, glm::vec3(0.1f, 1.0f, 0.1f));
    glUniformMatrix4fv(modelMatrixLoc, 1, GL_FALSE, glm::value_ptr(model));

    glDrawArrays(GL_TRIANGLE_FAN, 0, 34);
    glDrawArrays(GL_TRIANGLE_FAN, 34, 34);
    glDrawArrays(GL_TRIANGLE_STRIP, 68, 66);

    glUniform1i(useBlackColorLoc, 0);

    // Drawing the monitor on the desk
    glBindVertexArray(deskVAO);

    model = glm::mat4(1.0f);
    model = glm::translate(model, glm::vec3(-0.3f, 0.15f, -4.5f));
    model = glm::rotate(model, glm::radians(20.0f), glm::vec3(0.0f, 1.0f, 0.0f)); // Rotate 20 degrees inward
    model = glm::scale(model, glm::vec3(0.7f, 0.4f, 0.01f));
    glUniformMatrix4fv(modelMatrixLoc, 1, GL_FALSE, glm::value_ptr(model));

    glBindBuffer(GL_ARRAY_BUFFER, deskVBO);
    glUnmapBuffer(GL_ARRAY_BUFFER);
    glBindBuffer(GL_ARRAY_BUFFER, 0);

    bindTexture(1, monitorTexture, textureSamplerLoc);

    glDrawArrays(GL_TRIANGLES, 0, 36);
}

void drawComputer(
    GLuint computerVAO,
    GLuint fanVAO,
    GLuint cylinderVAO,
    GLuint modelMatrixLoc,
    GLuint textureSamplerLoc,
    GLuint useGreenColorLoc,
    GLuint monitorTexture,
    const std::vector<Vertex>& torusVertices)
{
    // Draw computer body
    glBindVertexArray(computerVAO);

    glm::mat4 model = glm::mat4(1.0f);
    model = glm::translate(model, glm::vec3(1.5f, 0.13f, -5.0f));
    model = glm::scale(model, glm::vec3(0.4f, 0.7f, 1.0f));
    glUniformMatrix4fv(modelMatrixLoc, 1, GL_FALSE, glm::value_ptr(model));

    glDrawArrays(GL_TRIANGLES, 0, 6);
    glDrawArrays(GL_TRIANGLES, 18, 18);

    // Draw fans with light
    std::vector<glm::vec3> fanPositions = {
        {1.65f, 0.35f, -4.7f},
        {1.65f, 0.13f, -4.7f},
        {1.65f, -0.10f, -4.7f},
        {1.5f, 0.35f, -5.45f},
        {1.5f, -0.2f, -5.35f},
        {1.5f, -0.2f, -5.05f},
        {1.5f, -0.2f, -4.75f},
        {1.5f, 0.44f, -5.15f},
        {1.5f, 0.44f, -4.90f}
    };

    std::vector<glm::vec3> fanRotations = {
        {90.0f, 0.0f, 90.0f},
        {90.0f, 0.0f, 90.0f},
        {90.0f, 0.0f, 90.0f},
        {0.0f, 90.0f, 90.0f},
        {0.0f, 0.0f, 0.0f},
        {0.0f, 0.0f, 0.0f},
        {0.0f, 0.0f, 0.0f},
        {0.0f, 0.0f, 0.0f},
        {0.0f, 0.0f, 0.0f}
    };

    std::vector<glm::vec3> torusRotations = {
    {0.0f, 90.0f, 0.0f},
    {0.0f, 90.0f, 0.0f},
    {0.0f, 90.0f, 0.0f},
    {0.0f, 0.0f, 90.0f},
    {90.0f, 0.0f, 0.0f},
    {90.0f, 0.0f, 0.0f},
    {90.0f, 0.0f, 0.0f},
    {90.0f, 0.0f, 0.0f},
    {90.0f, 0.0f, 0.0f}
    };

    for (size_t i = 0; i < fanPositions.size(); ++i) {
        DrawFanWithTorus(
            fanVAO, cylinderVAO,
            fanPositions[i], fanRotations[i],
            torusRotations[i],
            monitorTexture,
            modelMatrixLoc, textureSamplerLoc, useGreenColorLoc,
            torusVertices.size()
        );
    }
}

void drawKeyboard(
    GLuint computerVAO,
    GLuint modelMatrixLoc,
    GLuint textureSamplerLoc,
    GLuint mouseTexture)
{
    glBindVertexArray(computerVAO);

    glm::mat4 model = glm::mat4(1.0f);
    model = glm::translate(model, glm::vec3(-0.3f, -0.22f, -4.2f));
    model = glm::scale(model, glm::vec3(0.6f, 0.02f, 0.15f));
    glUniformMatrix4fv(modelMatrixLoc, 1, GL_FALSE, glm::value_ptr(model));

    bindTexture(2, mouseTexture, textureSamplerLoc);

    glDrawArrays(GL_TRIANGLES, 0, 36);
}

void drawMouse(
    GLuint cylinderVAO,
    GLuint modelMatrixLoc)
{
    glBindVertexArray(cylinderVAO);

    glm::mat4 model = glm::mat4(1.0f);
    model = glm::translate(model, glm::vec3(0.2f, -0.22f, -4.2f));
    model = glm::scale(model, glm::vec3(0.2f, 0.1f, 0.4f));
    glUniformMatrix4fv(modelMatrixLoc, 1, GL_FALSE, glm::value_ptr(model));

    glDrawArrays(GL_TRIANGLE_FAN, 0, 34);
    glDrawArrays(GL_TRIANGLE_FAN, 34, 34);
    glDrawArrays(GL_TRIANGLE_STRIP, 68, 66);
}

void drawGlass(
    GLuint computerVAO,
    GLuint modelMatrixLoc,
    GLuint glassTexture,
    GLuint textureSamplerLoc)
{
    glBindVertexArray(computerVAO);

    glm::mat4 model = glm::mat4(1.0f);
    model = glm::translate(model, glm::vec3(1.5f, 0.13f, -5.0f));
    model = glm::scale(model, glm::vec3(0.4f, 0.7f, 1.0f));
    glUniformMatrix4fv(modelMatrixLoc, 1, GL_FALSE, glm::value_ptr(model));

    bindTexture(3, glassTexture, textureSamplerLoc);

    glDrawArrays(GL_TRIANGLES, 6, 12);
}

GLuint compileShader(const char* shaderSource, GLenum shaderType) {
    // Create and compile the shader
    GLuint shader = glCreateShader(shaderType);
    glShaderSource(shader, 1, &shaderSource, NULL);
    glCompileShader(shader);

    // Check shader compile status
    GLint compileStatus;
    glGetShaderiv(shader, GL_COMPILE_STATUS, &compileStatus);
    if (compileStatus != GL_TRUE) {
        GLint maxLength;
        glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &maxLength);
        std::vector<GLchar> errorLog(maxLength);
        glGetShaderInfoLog(shader, maxLength, &maxLength, &errorLog[0]);

        // Clean up shader
        glDeleteShader(shader);

        // Print the error and return 0
        std::cerr << (shaderType == GL_VERTEX_SHADER ? "Vertex" : "Fragment")
            << " shader compilation failed:\n"
            << &errorLog[0] << std::endl;

        return 0;
    }

    return shader;
}

GLuint linkShaderProgram(GLuint vertexShader, GLuint fragmentShader) {
    glEnable(GL_DEPTH_TEST);
    GLuint shaderProgram = glCreateProgram();
    glAttachShader(shaderProgram, vertexShader);
    glAttachShader(shaderProgram, fragmentShader);
    glLinkProgram(shaderProgram);

    // Check shader program linking status
    GLint linkStatus;
    glGetProgramiv(shaderProgram, GL_LINK_STATUS, &linkStatus);
    if (linkStatus != GL_TRUE) {
        GLint maxLength;
        glGetProgramiv(shaderProgram, GL_INFO_LOG_LENGTH, &maxLength);
        std::vector<GLchar> errorLog(maxLength);
        glGetProgramInfoLog(shaderProgram, maxLength, &maxLength, &errorLog[0]);

        // Clean up program and shaders
        glDeleteProgram(shaderProgram);
        glDeleteShader(vertexShader);
        glDeleteShader(fragmentShader);

        // Print the error and return 0
        std::cerr << "Shader program linking failed:\n" << &errorLog[0] << std::endl;

        return 0;
    }

    // Cleanup shaders
    glDetachShader(shaderProgram, vertexShader);
    glDetachShader(shaderProgram, fragmentShader);
    glDeleteShader(vertexShader);
    glDeleteShader(fragmentShader);

    return shaderProgram;
}

GLuint loadTexture(const char* filename, GLenum format) {

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    int texWidth, texHeight, nrChannels;
    unsigned char* data = stbi_load(filename, &texWidth, &texHeight, &nrChannels, 0);

    GLuint texture;
    glGenTextures(1, &texture);
    glBindTexture(GL_TEXTURE_2D, texture);

    // set the texture wrapping/filtering options
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    // upload the texture data
    if (data) {
        if (format == GL_RGBA) {
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, texWidth, texHeight, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
        }
        else {
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, texWidth, texHeight, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
        }
        glGenerateMipmap(GL_TEXTURE_2D);
        // free the image data
        stbi_image_free(data);
    }
    else {
        std::cout << "Failed to load " << filename << " texture" << std::endl;
    }

    return texture;
}




int main() {

    // Initialize GLFW
    if (!glfwInit()) {
        std::cerr << "Failed to initialize GLFW" << std::endl;
        return -1;
    }

    int width = 1920, height = 1080;

    // Create a window
    GLFWwindow* window = glfwCreateWindow(width, height, "Final Project Jarrod Thomisee", NULL, NULL);
    if (!window) {
        std::cerr << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return -1;
    }


    // Allow for dynamic window resizing
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

    // Other callback functions
    glfwSetKeyCallback(window, key_callback);
    glfwSetCursorPosCallback(window, mouse_callback);
    glfwSetScrollCallback(window, scroll_callback);
    glfwSetMouseButtonCallback(window, mouse_button_callback);

    // Make the window's context current
    glfwMakeContextCurrent(window);

    // Initialize GLEW
    if (glewInit() != GLEW_OK) {
        std::cerr << "Failed to initialize GLEW" << std::endl;
        return -1;
    }


    GLuint vertexShader = compileShader(vertexShaderSource, GL_VERTEX_SHADER);
    GLuint fragmentShader = compileShader(fragmentShaderSource, GL_FRAGMENT_SHADER);

    if (!vertexShader || !fragmentShader) {
        return -1;
    }

    GLuint shaderProgram = linkShaderProgram(vertexShader, fragmentShader);
    if (!shaderProgram) {
        return -1;
    }

    // Load the textures
    GLuint deskTexture = loadTexture("desk_texture.jpg", GL_RGB);
    GLuint monitorTexture = loadTexture("monitor_texture.jpg", GL_RGB);
    GLuint glassTexture = loadTexture("glass_texture.png", GL_RGBA);
    GLuint mouseTexture = loadTexture("mouse_texture.jpg", GL_RGB);

    // Vertex data for the desk
    float deskVertices[] = {
        -0.5f, -0.5f, -0.5f,  1.0f, 0.0f, 0.0f,  0.0f, 0.0f,
         0.5f, -0.5f, -0.5f,  0.0f, 1.0f, 0.0f,  1.0f, 0.0f,
         0.5f,  0.5f, -0.5f,  0.0f, 0.0f, 1.0f,  1.0f, 1.0f,
         0.5f,  0.5f, -0.5f,  0.0f, 0.0f, 1.0f,  1.0f, 1.0f,
        -0.5f,  0.5f, -0.5f,  1.0f, 1.0f, 0.0f,  0.0f, 1.0f,
        -0.5f, -0.5f, -0.5f,  1.0f, 0.0f, 0.0f,  0.0f, 0.0f,
        -0.5f, -0.5f,  0.5f,  1.0f, 1.0f, 1.0f,  0.0f, 0.0f,
         0.5f, -0.5f,  0.5f,  1.0f, 0.0f, 0.0f,  1.0f, 0.0f,
         0.5f,  0.5f,  0.5f,  0.0f, 1.0f, 0.0f,  1.0f, 1.0f,
         0.5f,  0.5f,  0.5f,  0.0f, 1.0f, 0.0f,  1.0f, 1.0f,
        -0.5f,  0.5f,  0.5f,  1.0f, 1.0f, 0.0f,  0.0f, 1.0f,
        -0.5f, -0.5f,  0.5f,  1.0f, 0.0f, 0.0f,  0.0f, 0.0f,
        -0.5f,  0.5f,  0.5f,  0.0f, 1.0f, 1.0f,  0.0f, 1.0f,
        -0.5f,  0.5f, -0.5f,  1.0f, 1.0f, 1.0f,  0.0f, 0.0f,
        -0.5f, -0.5f, -0.5f,  1.0f, 0.0f, 0.0f,  1.0f, 0.0f,
        -0.5f, -0.5f, -0.5f,  1.0f, 0.0f, 0.0f,  1.0f, 0.0f,
        -0.5f, -0.5f,  0.5f,  0.0f, 1.0f, 0.0f,  1.0f, 1.0f,
        -0.5f,  0.5f,  0.5f,  0.0f, 1.0f, 1.0f,  0.0f, 1.0f,
         0.5f,  0.5f,  0.5f,  1.0f, 0.0f, 1.0f,  1.0f, 1.0f,
         0.5f,  0.5f, -0.5f,  0.0f, 1.0f, 1.0f,  1.0f, 0.0f,
         0.5f, -0.5f, -0.5f,  1.0f, 1.0f, 1.0f,  0.0f, 0.0f,
         0.5f, -0.5f, -0.5f,  1.0f, 0.0f, 0.0f,  0.0f, 0.0f,
         0.5f, -0.5f,  0.5f,  0.0f, 1.0f, 0.0f,  0.0f, 1.0f,
         0.5f,  0.5f,  0.5f,  1.0f, 0.0f, 1.0f,  1.0f, 1.0f,
        -0.5f, -0.5f, -0.5f,  1.0f, 1.0f, 0.0f,  1.0f, 0.0f,
         0.5f, -0.5f, -0.5f,  1.0f, 0.0f, 1.0f,  0.0f, 0.0f,
         0.5f, -0.5f,  0.5f,  0.0f, 1.0f, 1.0f,  0.0f, 1.0f,
         0.5f, -0.5f,  0.5f,  1.0f, 1.0f, 1.0f,  0.0f, 1.0f,
        -0.5f, -0.5f,  0.5f,  1.0f, 0.0f, 0.0f,  1.0f, 1.0f,
        -0.5f, -0.5f, -0.5f,  1.0f, 1.0f, 0.0f,  1.0f, 0.0f,
        -0.5f,  0.5f, -0.5f,  1.0f, 0.0f, 1.0f,  0.0f, 1.0f,
         0.5f,  0.5f, -0.5f,  0.0f, 1.0f, 0.0f,  1.0f, 1.0f,
         0.5f,  0.5f,  0.5f,  1.0f, 1.0f, 1.0f,  1.0f, 0.0f,
         0.5f,  0.5f,  0.5f,  1.0f, 0.0f, 0.0f,  1.0f, 0.0f,
        -0.5f,  0.5f,  0.5f,  0.0f, 1.0f, 1.0f,  0.0f, 0.0f,
        -0.5f,  0.5f, -0.5f,  1.0f, 0.0f, 1.0f,  0.0f, 1.0f
    };

    // Create a vertex buffer object (VBO) and a vertex array object (VAO)
    GLuint deskVBO, deskVAO;
    glGenVertexArrays(1, &deskVAO);
    glGenBuffers(1, &deskVBO);

    glBindVertexArray(deskVAO);

    glBindBuffer(GL_ARRAY_BUFFER, deskVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(deskVertices), deskVertices, GL_STATIC_DRAW);

    // position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    // color attribute
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    // texture coord attribute
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
    glEnableVertexAttribArray(2);

    glBindBuffer(GL_ARRAY_BUFFER, 0);

    glBindVertexArray(0);

    std::vector<Vertex> torusVertices = generateTorus(1.0f, 0.1f, 50, 25);

    GLuint fanVBO, fanVAO;
    glGenBuffers(1, &fanVBO);
    glBindBuffer(GL_ARRAY_BUFFER, fanVBO);
    glBufferData(GL_ARRAY_BUFFER, torusVertices.size() * sizeof(Vertex), &torusVertices[0], GL_STATIC_DRAW);

    glGenVertexArrays(1, &fanVAO);
    glBindVertexArray(fanVAO);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (GLvoid*)(sizeof(float) * 3));
    glEnableVertexAttribArray(1);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);



    // Vertex data for the computer
    float computerVertices[] = {
        // Positions          // Colors           // Texture Coords
        -0.5f, -0.5f, -0.5f,  1.0f, 0.0f, 0.0f,  0.0f, 0.0f,
         0.5f, -0.5f, -0.5f,  0.0f, 1.0f, 0.0f,  1.0f, 0.0f,
         0.5f,  0.5f, -0.5f,  0.0f, 0.0f, 1.0f,  1.0f, 1.0f,
         0.5f,  0.5f, -0.5f,  0.0f, 0.0f, 1.0f,  1.0f, 1.0f,
        -0.5f,  0.5f, -0.5f,  1.0f, 1.0f, 0.0f,  0.0f, 1.0f,
        -0.5f, -0.5f, -0.5f,  1.0f, 0.0f, 0.0f,  0.0f, 0.0f,

        -0.5f, -0.5f,  0.5f,  1.0f, 0.0f, 0.0f,  0.0f, 0.0f,
         0.5f, -0.5f,  0.5f,  0.0f, 1.0f, 0.0f,  1.0f, 0.0f,
         0.5f,  0.5f,  0.5f,  0.0f, 0.0f, 1.0f,  1.0f, 1.0f,
         0.5f,  0.5f,  0.5f,  0.0f, 0.0f, 1.0f,  1.0f, 1.0f,
        -0.5f,  0.5f,  0.5f,  1.0f, 1.0f, 0.0f,  0.0f, 1.0f,
        -0.5f, -0.5f,  0.5f,  1.0f, 0.0f, 0.0f,  0.0f, 0.0f,

        -0.5f,  0.5f,  0.5f,  1.0f, 0.0f, 0.0f,  1.0f, 0.0f,
        -0.5f,  0.5f, -0.5f,  0.0f, 1.0f, 0.0f,  1.0f, 1.0f,
        -0.5f, -0.5f, -0.5f,  0.0f, 0.0f, 1.0f,  0.0f, 1.0f,
        -0.5f, -0.5f, -0.5f,  0.0f, 0.0f, 1.0f,  0.0f, 1.0f,
        -0.5f, -0.5f,  0.5f,  1.0f, 1.0f, 0.0f,  0.0f, 0.0f,
        -0.5f,  0.5f,  0.5f,  1.0f, 0.0f, 0.0f,  1.0f, 0.0f,

         0.5f,  0.5f,  0.5f,  1.0f, 0.0f, 0.0f,  1.0f, 0.0f,
         0.5f,  0.5f, -0.5f,  0.0f, 1.0f, 0.0f,  1.0f, 1.0f,
         0.5f, -0.5f, -0.5f,  0.0f, 0.0f, 1.0f,  0.0f, 1.0f,
         0.5f, -0.5f, -0.5f,  0.0f, 0.0f, 1.0f,  0.0f, 1.0f,
         0.5f, -0.5f,  0.5f,  1.0f, 1.0f, 0.0f,  0.0f, 0.0f,
         0.5f,  0.5f,  0.5f,  1.0f, 0.0f, 0.0f,  1.0f, 0.0f,

        -0.5f, -0.5f, -0.5f,  1.0f, 0.0f, 0.0f,  0.0f, 1.0f,
         0.5f, -0.5f, -0.5f,  0.0f, 1.0f, 0.0f,  1.0f, 1.0f,
         0.5f, -0.5f,  0.5f,  0.0f, 0.0f, 1.0f,  1.0f, 0.0f,
         0.5f, -0.5f,  0.5f,  0.0f, 0.0f, 1.0f,  1.0f, 0.0f,
        -0.5f, -0.5f,  0.5f,  1.0f, 1.0f, 0.0f,  0.0f, 0.0f,
        -0.5f, -0.5f, -0.5f,  1.0f, 0.0f, 0.0f,  0.0f, 1.0f,

        -0.5f,  0.5f, -0.5f,  1.0f, 0.0f, 0.0f,  0.0f, 1.0f,
         0.5f,  0.5f, -0.5f,  0.0f, 1.0f, 0.0f,  1.0f, 1.0f,
         0.5f,  0.5f,  0.5f,  0.0f, 0.0f, 1.0f,  1.0f, 0.0f,
         0.5f,  0.5f,  0.5f,  0.0f, 0.0f, 1.0f,  1.0f, 0.0f,
        -0.5f,  0.5f,  0.5f,  1.0f, 1.0f, 0.0f,  0.0f, 0.0f,
        -0.5f,  0.5f, -0.5f,  1.0f, 0.0f, 0.0f,  0.0f, 1.0f
    };


    // Create VAO and VBO for the computer
    GLuint computerVAO, computerVBO;
    glGenVertexArrays(1, &computerVAO);
    glGenBuffers(1, &computerVBO);

    glBindVertexArray(computerVAO);
    glBindBuffer(GL_ARRAY_BUFFER, computerVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(computerVertices), computerVertices, GL_STATIC_DRAW);

    // Define the attribute pointers for the computer
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 8 * sizeof(float), (void*)(6 * sizeof(float)));
    glEnableVertexAttribArray(2);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);


    std::vector<float> cylinderVertices;
    generateCylinder(0.2f, 0.2f, 32, cylinderVertices);

    GLuint cylinderVAO, cylinderVBO;
    glGenVertexArrays(1, &cylinderVAO);
    glGenBuffers(1, &cylinderVBO);

    glBindVertexArray(cylinderVAO);
    glBindBuffer(GL_ARRAY_BUFFER, cylinderVBO);
    glBufferData(GL_ARRAY_BUFFER, cylinderVertices.size() * sizeof(float), &cylinderVertices[0], GL_STATIC_DRAW);

    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, 6 * sizeof(float), (void*)(3 * sizeof(float)));
    glEnableVertexAttribArray(1);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);

    glUseProgram(shaderProgram);

    //Shader Variables
    GLuint shininessLocation = glGetUniformLocation(shaderProgram, "materialShininess");
    GLuint lightColorLoc = glGetUniformLocation(shaderProgram, "lightColor");
    GLuint lightPosLoc = glGetUniformLocation(shaderProgram, "lightPos");
    GLuint viewPosLoc = glGetUniformLocation(shaderProgram, "viewPos");
    GLuint computerLightPosLoc = glGetUniformLocation(shaderProgram, "computerLightPos");
    GLuint computerLightColorLoc = glGetUniformLocation(shaderProgram, "computerLightColor");
    GLuint ambientStrengthLoc = glGetUniformLocation(shaderProgram, "ambientStrength");
    GLuint diffuseStrengthLoc = glGetUniformLocation(shaderProgram, "diffuseStrength");
    GLuint specularStrengthLoc = glGetUniformLocation(shaderProgram, "specularStrength");
    GLuint computerDiffuseStrengthLoc = glGetUniformLocation(shaderProgram, "computerDiffuseStrength");
    GLuint deskShininessLoc = glGetUniformLocation(shaderProgram, "deskShininess");
    GLuint viewMatrixLoc = glGetUniformLocation(shaderProgram, "view");
    GLuint projectionMatrixLoc = glGetUniformLocation(shaderProgram, "projection");
    GLuint modelMatrixLoc = glGetUniformLocation(shaderProgram, "model");
    GLuint textureSamplerLoc = glGetUniformLocation(shaderProgram, "textureSampler");
    GLuint useBlackColorLoc = glGetUniformLocation(shaderProgram, "useBlackColor");
    GLuint useGreenColorLoc = glGetUniformLocation(shaderProgram, "useGreenColor");

    glUniform3fv(lightColorLoc, 1, &lightColor[0]);
    glUniform3fv(lightPosLoc, 1, &lightPos[0]);
    glUniform1f(ambientStrengthLoc, ambientStrength);
    glUniform1f(diffuseStrengthLoc, diffuseStrength);
    glUniform1f(specularStrengthLoc, specularStrength);
    glUniform1f(computerDiffuseStrengthLoc, computerDiffuseStrength);
    glUniform3fv(computerLightPosLoc, 1, &computerLightPos[0]);
    glUniform3fv(computerLightColorLoc, 1, &computerLightColor[0]);
    glUniform1f(shininessLocation, materialShininess);




    // Main loop
    while (!glfwWindowShouldClose(window)) {
        // Clear the screen
        glClearColor(0.2f, 0.2f, 0.2f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // Use the shader program
        glUseProgram(shaderProgram);

        glUniform3fv(viewPosLoc, 1, &cameraPos[0]);
        
        // Create MVP matrix
        glm::mat4 model;
        glm::mat4 view;
        glm::mat4 projection;
        glm::mat4 mvp;

        model = glm::mat4(1.0f);
        view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);

        // Toggle Projection Matrix
        if (usePerspective) {
            projection = glm::perspective(glm::radians(45.0f), (float)width / (float)height, 0.1f, 100.0f);
        }
        else {
            float orthoScale = 5.0f;
            projection = glm::ortho(-orthoScale, orthoScale, -orthoScale, orthoScale, 0.1f, 100.0f);
        }

        mvp = projection * view * model;


        // Set the transformation matrices as uniform variables
        glUniformMatrix4fv(viewMatrixLoc, 1, GL_FALSE, glm::value_ptr(view));
        glUniformMatrix4fv(projectionMatrixLoc, 1, GL_FALSE, glm::value_ptr(projection));

        // Draw the desk
        drawDesk(modelMatrixLoc, deskVAO, deskTexture, textureSamplerLoc, deskVBO);

        // Draw the monitor
        drawMonitor(cylinderVAO, deskVAO, deskVBO, modelMatrixLoc, useBlackColorLoc, monitorTexture, textureSamplerLoc);

        // Draw the computer
        drawComputer(computerVAO, fanVAO, cylinderVAO, modelMatrixLoc, textureSamplerLoc, useGreenColorLoc, monitorTexture, torusVertices);

        // Draw the keyboard
        drawKeyboard(computerVAO, modelMatrixLoc, textureSamplerLoc, mouseTexture);

        // Draw the mouse
        drawMouse(cylinderVAO, modelMatrixLoc);

        // Draw the glass panels
        drawGlass(computerVAO, modelMatrixLoc, glassTexture, textureSamplerLoc);


        // Swap buffers and poll events
        glfwSwapBuffers(window);
        glfwPollEvents();
    }

    // Cleanup
    glDeleteVertexArrays(1, &deskVAO);
    glDeleteVertexArrays(1, &cylinderVAO);
    glDeleteVertexArrays(1, &computerVAO);
    glDeleteVertexArrays(1, &fanVAO);
    glDeleteBuffers(1, &deskVBO);
    glDeleteBuffers(1, &cylinderVBO);
    glDeleteBuffers(1, &computerVBO);
    glDeleteVertexArrays(1, &fanVAO);

    glfwDestroyWindow(window);
    glfwTerminate();

    return 0;
}