package com.snhu.eventtracker.adapter;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.snhu.eventtracker.R;
import com.snhu.eventtracker.database.AppDatabase;
import com.snhu.eventtracker.model.Event;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executors;

// Adapter class for the RecyclerView, handling Event objects.
public class EventsAdapter extends RecyclerView.Adapter<EventsAdapter.EventViewHolder> {

    private List<Event> events;
    private OnItemClickListener listener;

    // Constructor to initialize the adapter with a list of events.
    public EventsAdapter(List<Event> events) {
        this.events = events;
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.event_item_layout, parent, false);
        return new EventViewHolder(view);
    }

    // Method to bind data to each ViewHolder, setting up the event details and click listeners.
    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
        Event event = events.get(position);
        holder.eventName.setText(event.getName());
        holder.eventLocation.setText(event.getLocation());
        holder.eventDate.setText(formatDate(event.getDate()));

        // Set background color dynamically
        holder.itemView.setBackgroundColor(Color.parseColor(event.getColor()));

        // Set click listener for delete button
        holder.deleteEventButton.setOnClickListener(v -> {
            // Get the event at this position
            Event eventToDelete = events.get(position);
            // Call the deleteEvent method in the EventDao
            Executors.newSingleThreadExecutor().execute(() -> {
                AppDatabase db = AppDatabase.getDbInstance(holder.itemView.getContext().getApplicationContext());
                db.eventDao().deleteEvent(eventToDelete);
                // Remove the event from the list
                events.remove(eventToDelete);
                holder.itemView.post(() -> notifyDataSetChanged());
            });
        });

        // Set click listener for item view
        holder.itemView.setOnClickListener(v -> {
            int pos = holder.getAdapterPosition();
            if (listener != null && pos != RecyclerView.NO_POSITION) {
                listener.onItemClick(events.get(pos));
            }
        });
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    // Returns the total number of items in the data set.
    @Override
    public int getItemCount() {
        return events.size();
    }

    // Helper method to format the event's timestamp into a readable date string.
    private String formatDate(long timestamp) {
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm a", Locale.getDefault());
        Date date = new Date(timestamp);

        return sdf.format(date);
    }

    // Method to update the list of events and refresh the RecyclerView.
    public void setEvents(List<Event> events) {
        this.events = events;
        notifyDataSetChanged();
    }

    public interface OnItemClickListener {
        void onItemClick(Event event);
    }

    static class EventViewHolder extends RecyclerView.ViewHolder {
        TextView eventName;
        TextView eventLocation;
        TextView eventDate;
        ImageButton deleteEventButton;

        public EventViewHolder(@NonNull View itemView) {
            super(itemView);
            eventName = itemView.findViewById(R.id.eventNameTextView);
            eventLocation = itemView.findViewById(R.id.eventLocationTextView);
            eventDate = itemView.findViewById(R.id.eventDateTextView);
            deleteEventButton = itemView.findViewById(R.id.deleteEventButton);
        }
    }
}
