package com.snhu.eventtracker.activity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.snhu.eventtracker.R;
import com.snhu.eventtracker.adapter.EventsAdapter;
import com.snhu.eventtracker.database.AppDatabase;
import com.snhu.eventtracker.model.Event;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;

public class EventDisplayActivity extends AppCompatActivity {

    private RecyclerView eventsRecyclerView;
    private Button addEventButton;
    private EventsAdapter adapter;
    private long userId;
    private ActivityResultLauncher<Intent> createEventLauncher;
    private ActivityResultLauncher<Intent> editEventLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_display);

        // Register launcher for creating new events
        createEventLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        // Refresh events after creating a new event
                        loadEvents();
                    }
                });

        // Register launcher for editing events
        editEventLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        // Refresh events after editing an event
                        loadEvents();
                    }
                });

        eventsRecyclerView = findViewById(R.id.eventsRecyclerView);
        addEventButton = findViewById(R.id.newEventButton);
        this.userId = getIntent().getLongExtra("USER_ID", -1);

        eventsRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new EventsAdapter(new ArrayList<>()); // Initialize with an empty list
        eventsRecyclerView.setAdapter(adapter);

        // Set item click listener on the adapter
        adapter.setOnItemClickListener(new EventsAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Event event) {
                // Open edit activity for the clicked event
                Intent intent = new Intent(EventDisplayActivity.this, CreateEventActivity.class);
                intent.putExtra("USER_ID", userId);
                intent.putExtra("EVENT_ID", event.getId());
                // Launch the activity using the edit event launcher
                editEventLauncher.launch(intent);
            }
        });

        addEventButton.setOnClickListener(v -> {
            // Intent to open CreateEventActivity for creating new event
            Intent intent = new Intent(EventDisplayActivity.this, CreateEventActivity.class);
            intent.putExtra("USER_ID", userId);
            // Launch the activity using the create event launcher
            createEventLauncher.launch(intent);
        });

        // Load events from database
        loadEvents();
    }

    private void loadEvents() {
        Executors.newSingleThreadExecutor().execute(() -> {
            AppDatabase db = AppDatabase.getDbInstance(EventDisplayActivity.this.getApplicationContext());
            List<Event> events;
            events = db.eventDao().getEventsByUserId(userId);

            runOnUiThread(() -> {
                adapter.setEvents(events);
            });
        });
    }
}
