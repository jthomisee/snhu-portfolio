package com.snhu.eventtracker.database;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.snhu.eventtracker.dao.EventDao;
import com.snhu.eventtracker.dao.UserDao;
import com.snhu.eventtracker.model.Event;
import com.snhu.eventtracker.model.User;

// Room Database with two entities (User and Event)
@Database(entities = {User.class, Event.class}, version = 3)
public abstract class AppDatabase extends RoomDatabase {
    // INSTANCE to hold a singleton instance of the database.
    private static volatile AppDatabase INSTANCE;

    public static AppDatabase getDbInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    // Create the database
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    AppDatabase.class, "event_tracker") // Database name is "event_tracker"
                            .fallbackToDestructiveMigration()
                            .build(); // Build the database instance
                }
            }
        }
        return INSTANCE;
    }

    public abstract UserDao userDao();

    public abstract EventDao eventDao();
}
