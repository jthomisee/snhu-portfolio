package com.snhu.eventtracker.activity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TimePicker;

import androidx.appcompat.app.AppCompatActivity;

import com.snhu.eventtracker.R;
import com.snhu.eventtracker.database.AppDatabase;
import com.snhu.eventtracker.model.Event;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.Executors;

public class CreateEventActivity extends AppCompatActivity {

    private EditText eventNameEditText;
    private EditText eventLocationEditText;
    private DatePicker eventDatePicker;
    private TimePicker eventTimePicker;
    private Spinner eventColorSpinner;
    private Button saveEventButton;
    private AppDatabase db;
    private long userId;
    private long eventId = -1; // Default value indicating a new event

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_event);

        eventNameEditText = findViewById(R.id.eventNameEditText);
        eventLocationEditText = findViewById(R.id.eventLocationEditText);
        eventDatePicker = findViewById(R.id.eventDatePicker); // Initialize DatePicker
        eventTimePicker = findViewById(R.id.eventTimePicker); // Initialize TimePicker
        eventTimePicker.setIs24HourView(true);
        eventColorSpinner = findViewById(R.id.eventColorSpinner);
        saveEventButton = findViewById(R.id.saveEventButton);
        db = AppDatabase.getDbInstance(this.getApplicationContext());
        userId = getIntent().getLongExtra("USER_ID", -1);

        // Check for an event ID in the intent. If present, this activity will edit an existing event.
        if (getIntent().hasExtra("EVENT_ID")) {
            eventId = getIntent().getLongExtra("EVENT_ID", -1);
            // Load existing event details for editing
            loadEventDetails(eventId);
        }

        // Setting up the spinner with color options for the event.
        ArrayAdapter<CharSequence> colorAdapter = ArrayAdapter.createFromResource(
                this,
                R.array.color_options, // Resource ID in arrays.xml
                android.R.layout.simple_spinner_item
        );
        colorAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        eventColorSpinner.setAdapter(colorAdapter);        colorAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        eventColorSpinner.setAdapter(colorAdapter);

        saveEventButton.setOnClickListener(v -> saveEvent(userId));
    }

    // Loads event details from the database and populates the UI with these details.
    private void loadEventDetails(long eventId) {
        Executors.newSingleThreadExecutor().execute(() -> {
            // Retrieve event details from the database based on the event ID
            AppDatabase db = AppDatabase.getDbInstance(this.getApplicationContext());
            Event event = db.eventDao().getEventById(eventId);

            // Check if the event exists
            if (event != null) {
                // Post the UI update on the main thread
                runOnUiThread(() -> {
                    // Populate the EditText fields with the event details
                    eventNameEditText.setText(event.getName());
                    eventLocationEditText.setText(event.getLocation());

                    // Set the date and time in DatePicker and TimePicker
                    Calendar calendar = Calendar.getInstance();
                    calendar.setTimeInMillis(event.getDate());
                    eventDatePicker.updateDate(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
                    eventTimePicker.setHour(calendar.get(Calendar.HOUR_OF_DAY));
                    eventTimePicker.setMinute(calendar.get(Calendar.MINUTE));

                    // Set the selected color in Spinner
                    ArrayAdapter<String> adapter = (ArrayAdapter<String>) eventColorSpinner.getAdapter();
                    int position = adapter.getPosition(event.getColor());
                    if (position != -1) {
                        eventColorSpinner.setSelection(position);
                    }
                });
            }
        });
    }


    private void saveEvent(long userId) {
        String eventName = eventNameEditText.getText().toString().trim();
        String location = eventLocationEditText.getText().toString().trim();
        String color = eventColorSpinner.getSelectedItem().toString();

        // Get the selected date from DatePicker
        int year = eventDatePicker.getYear();
        int month = eventDatePicker.getMonth();
        int dayOfMonth = eventDatePicker.getDayOfMonth();
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, dayOfMonth);

        // Get the selected time from TimePicker
        int hour = eventTimePicker.getHour();
        int minute = eventTimePicker.getMinute();
        calendar.set(Calendar.HOUR_OF_DAY, hour);
        calendar.set(Calendar.MINUTE, minute);

        // Get the combined milliseconds value
        long dateTime = calendar.getTimeInMillis();

        // Create the event object
        Event event = new Event(eventName, dateTime, location, color);
        event.setUserId(userId);

        // If event ID is provided, update the existing event, otherwise insert a new event
        if (eventId != -1) {
            event.setId(eventId);
            updateEvent(event);
        } else {
            insertEvent(event);
        }
    }


    private void insertEvent(Event event) {
        Executors.newSingleThreadExecutor().execute(() -> {
            db.eventDao().insertEvent(event);
            runOnUiThread(() -> {
                setResult(RESULT_OK);
                finish();
            });
        });
    }

    private void updateEvent(Event event) {
        Executors.newSingleThreadExecutor().execute(() -> {
            db.eventDao().updateEvent(event);
            runOnUiThread(() -> {
                setResult(RESULT_OK);
                finish();
            });
        });
    }
}
