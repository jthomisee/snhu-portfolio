package com.snhu.eventtracker.activity;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.snhu.eventtracker.R;
import com.snhu.eventtracker.database.AppDatabase;
import com.snhu.eventtracker.model.User;

import org.mindrot.jbcrypt.BCrypt;


public class MainActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_REQUEST_CODE = 1001;
    private EditText phoneNumberEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private Button registerButton;
    private AppDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        phoneNumberEditText = findViewById(R.id.phoneNumberEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);
        registerButton = findViewById(R.id.registerButton);
        db = AppDatabase.getDbInstance(this.getApplicationContext());

        loginButton.setOnClickListener(v -> login());
        registerButton.setOnClickListener(v -> register());

        // Check for SMS permission
        checkSmsPermission();
    }
    // Function to handle existing user logins
    private void login() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                String phone_number = phoneNumberEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                // Check if phone number and password are not empty
                if (phone_number.isEmpty() || password.isEmpty()) {
                    return;
                }

                User user = db.userDao().getUserByPhone(phone_number);

                // If user login is successful
                if (user != null && BCrypt.checkpw(password, user.getPassword())) {
                    int userId = user.getId();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            navigateToEventDisplayActivity(userId);
                        }
                    });
                } else {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(MainActivity.this, "Invalid Login", Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        }).start();
    }

    // Handle new user registration
    private void register() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                // Try to create new user and display error if user with that phone number already exists
                try {
                    String phone_number = phoneNumberEditText.getText().toString();
                    String password = passwordEditText.getText().toString();

                    // Check if phone number and password are not empty
                    if (phone_number.isEmpty() || password.isEmpty()) {
                        return;
                    }

                    String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt());

                    User newUser = new User(phone_number, hashedPassword);
                    long userId = db.userDao().insertUser(newUser);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            navigateToEventDisplayActivity(userId);
                        }
                    });
                } catch (android.database.sqlite.SQLiteConstraintException e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(MainActivity.this, "User with this phone number already exists.", Toast.LENGTH_LONG).show();
                        }
                    });
                } catch (Exception e) {
                    // Handle other exceptions
                    e.printStackTrace();
                }
            }
        }).start();
    }

    private void checkSmsPermission() {
        // Checking if it's the users first time launching the app
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        boolean isFirstLaunch = prefs.getBoolean("first_launch", true);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            if (isFirstLaunch || ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
                // It's the first launch or permission was denied (but user did not select "Do not ask me again")
                // Request the SEND_SMS permission
                navigateToRequestSMSActivity();
                // Update the flag indicating it's not the first launch
                prefs.edit().putBoolean("first_launch", false).apply();
            }
        }
    }

    private void navigateToEventDisplayActivity(long userId) {
        Intent intent = new Intent(MainActivity.this, EventDisplayActivity.class);
        intent.putExtra("USER_ID", userId);
        startActivity(intent);
    }

    private void navigateToRequestSMSActivity() {
        Intent intent = new Intent(MainActivity.this, RequestSMSActivity.class);
        startActivity(intent);
    }


}
