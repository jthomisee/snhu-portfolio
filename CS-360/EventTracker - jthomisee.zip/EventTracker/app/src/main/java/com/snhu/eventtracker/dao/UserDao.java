package com.snhu.eventtracker.dao;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import com.snhu.eventtracker.model.User;

@Dao
public interface UserDao {
    @Insert
    long insertUser(User user);

    @Query("SELECT * FROM users WHERE phone_number = :phoneNumber")
    User getUserByPhone(String phoneNumber);
}
