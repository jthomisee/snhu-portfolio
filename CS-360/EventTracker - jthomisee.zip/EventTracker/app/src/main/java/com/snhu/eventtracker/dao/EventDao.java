package com.snhu.eventtracker.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.snhu.eventtracker.model.Event;

import java.util.List;

@Dao
public interface EventDao {

    @Insert
    void insertEvent(Event event);

    @Query("SELECT * FROM events WHERE userId = :userId")
    List<Event> getEventsByUserId(long userId);

    @Delete
    void deleteEvent(Event event);

    @Update
    void updateEvent(Event event);

    @Query("SELECT * FROM events WHERE id = :eventId")
    Event getEventById(long eventId);

}
